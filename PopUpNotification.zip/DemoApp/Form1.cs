﻿/*
 *	Created/modified in 2011 by Simon Baer
 *	
 *  Licensed under the Code Project Open License (CPOL).
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace DemoApp
{
  

    public partial class Form1 : Form
    {
        private System.Windows.Forms.Timer tmr;
        public Form1()
        {
           
            InitializeComponent();
            Show();
            tmr = new System.Windows.Forms.Timer();
            tmr.Tick += delegate {
                this.Close();
            };
            tmr.Interval = (int)TimeSpan.FromSeconds(5).TotalMilliseconds;
            tmr.Start();
        }

        private void Show()
        {
            popupNotifier1.TitleText = "Hi";
            popupNotifier1.ContentText = "This is me! Popup";
            popupNotifier1.ShowCloseButton = true;
            popupNotifier1.ShowOptionsButton = true;
            popupNotifier1.ShowGrip = true;
            popupNotifier1.Delay = 3000;//ms
            popupNotifier1.AnimationInterval = 10;//ms
            popupNotifier1.AnimationDuration = 1000;//ms
            popupNotifier1.Scroll = true;
            popupNotifier1.TitlePadding = new Padding(0);
            popupNotifier1.ContentPadding = new Padding(0);
            popupNotifier1.ImagePadding = new Padding(0);

            if (false)
            {
                popupNotifier1.Image = Properties.Resources._157_GetPermission_48x48_72;
            }
            else
            {
                popupNotifier1.Image = null;
            }
            
            popupNotifier1.Popup();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {

        }
    }
}
